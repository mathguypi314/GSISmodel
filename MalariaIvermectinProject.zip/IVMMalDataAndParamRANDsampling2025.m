%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% this script does the same thing as GutMalScriptV4, but considers random
% parameter samples
%parameter values (for rates in ODE model)
rp=1./unifrnd(21,35,sampsize,1); % 1/rp ~ 28;
ru=1./110*ones(sampsize,1); 
rd=1./5*ones(sampsize,1); 
rt=1./5*ones(sampsize,1); 
ra=1./195*ones(sampsize,1); 
ft=0.5*ones(sampsize,1);
phi=0.5*ones(sampsize,1);

k = 6.46; % number of contacts by mos w/ humans 
%alpha=normrnd(0.25,0.04,sampsize,1);
mu = 0.74.*ones(sampsize,1); %0.798*ones(sampsize,1); % 0.5390*ones(sampsize,1);
beta=betarnd(12.5,16.35,sampsize,1);
d0 =1./lognrnd(1.98,0.31,sampsize,1); %1/7.6*ones(sampsize,1);% %7.6; %mos death rate
newd0 =1./lognrnd(1.4471,0.31,sampsize,1); %<-- adjusted so mean = 7.6 - (5.52-2.38) days w/ same std.
c = 1./unifrnd(2,3,sampsize,1); %exprnd(1/3,sampsize,1)'; %1/3*ones(sampsize,1); % 1/3; 
n = 1./normrnd(0.10533,0.01,sampsize,1);%1/0.10533*ones(sampsize,1);

%prob mosquitoes die w/ contact w/ ivermectine
psi = random(makedist('Triangular','a',0.6225,'b',0.8539,'c',0.8933),sampsize,1); %comes from  from figure 2 in Ivermectin Mass Drug Administration to Humans Disrupts Malaria Parasite Transmission in Senegalese Villages (see powerpoint figure)
%old psi ? random(makedist('Triangular','a',0,'b',0.338,'c',1),sampsize,1);

%parameter values (for DALY calc)
r = 0.03/365; % 3% discount rate PER year -> switch to daily

%population size
poplist =[18498000 8791832 1990876 15730977 8988091 18879301 4511488 ...
10329208 752438 3700000 68692542 20617068 516055 5647168 85237338 ...
1514993 1782893 24200000 10057975 1647000 39002772 4128572 19625000 ...
14268711 12666987 3359185 21669278 2108665 17129076 174507539 10473282 ...
212679 12855153 6190280 9832017 31894000 44928923 7154237 32369558 ...
11862740 11392629];

%Entomological inoculation rate (taken from Incidence and admission rates
%for severe malaria and their impact on mortality in Africa (2017) )
EIRlist = [18.0900000000000,35.5500000000000,0.390000000000000,61.1500000000000,3.57000000000000,34.0700000000000,35.7300000000000,14.6700000000000,19.7100000000000,18.0700000000000,23.3200000000000,40.5600000000000,0.0300000000000000,41.7800000000000,0.570000000000000,29.5900000000000,1.52000000000000,21.4000000000000,19.0600000000000,2.18000000000000,2.80000000000000,19.6500000000000,22.8700000000000,22.0200000000000,38.5300000000000,2.58000000000000,30.0700000000000,3.66000000000000,15.3000000000000,30.5100000000000,0.480000000000000,2.22000000000000,1.86000000000000,25.5500000000000,0.770000000000000,3.65000000000000,8.16000000000000,32.6200000000000,25.9700000000000,7.18000000000000,1.12000000000000];

% % IHME, Global Burden of Disease Study (2019) � processed by Our World in Data. �Share of the population with malaria� [dataset]. IHME, Global Burden of Disease Study (2019) [original data].
prevlist =  1/100.*[10.5000000000000,29.1000000000000,0.100000000000000,27.9000000000000,31.5000000000000,18.9000000000000,24,7.70000000000000,2.60000000000000,17.4000000000000,22.9000000000000,25.9000000000000,1.20000000000000,30.2000000000000,3.70000000000000,17.5000000000000,2.40000000000000,17.8000000000000,27.3000000000000,2.40000000000000,6.30000000000000,35,5.30000000000000,13.8000000000000,10.6000000000000,7.10000000000000,23.1000000000000,2.70000000000000,22.2000000000000,17.7000000000000,11.6000000000000,1,2.30000000000000,31.6000000000000,4.10000000000000,3.40000000000000,6,24.6000000000000,31.2000000000000,10.6000000000000,1.20000000000000];

%data source for per-country estimates of malaria incidence
%https://www.who.int/data/gho/data/indicators/indicator-details/GHO/estimated-number-of-malaria-cases
inc2018 = [6700267,4872597,808,7280725,3315862,6218960,1654108,3216108, ...
15186,1321959,6730934,27944491,24845,99716,2793314,499577, ...
196160,5314525,4508348,125653,3068062,1966210,1921403,3859499, ...
7710138,236485,9406462,50217,7760340,59652248,6184131,2937, ...
1047659,2901372,913696,2485883,6852548,2014395,10905744,3189765, ...
634718];

%Note: 2019 malaria incidence data, as reported by the WHO, was obtained 
%from https://apps.who.int/gho/data/view.main.MALARIAESTCASESvc?lang=en
inc2019 = [7352473,4937253,259,7472680,3549058,6246049,1681948,3277966, ...
17599,1324386,7184054,28830863,49402,200382,2645193,512184, ...
109975,5242734,4425904,146986,3037541,1954336,2032961,3867128, ...
6863255,184057,9421431,5705,7631511,61379283,5279485,2732, ...
672221,2857585,957015,2835630,7040493,1966638,11282360,3205531, ...
782740];

%In-patient cases (per 100,000 per year) for all countries (i.e. reported cases)
%Note 0.618 is proportion that reports to health care setting
% % x = 0.618*y so y = 1/0.618*x;

%Gross domestic product per capita
GDPlist = 1/10*[41703,8298,75956,6707,3201,14467,4184,6999,7973,4578,...
    16624,19276,98500,5828,7676,72207,4830,16415,8253,7237,15078,4561,4497,...
    3385,8245,11368,4157,52272,3781,19686,7484,19130,10331,4994, ...
    4998,28985,9363,6172,6040,15098,10796]'; %note the 1/10 out front is so I don't have to add a decimal to each # in the list

%%%%%NOTE the 0.618 = prop that reports to health care setting!!
omega = betarnd(65.4,40.42,sampsize,1); 

PropSevere=omega*[0.300365186,0.263841742,0.283377, ...
    0.162020708,0.237877079,0.116040791,0.416405582, ...
    0.25771297,0.283377,0.132566372,0.328749528, ...
    0.402791302,0.27994012,0.04249668,0.068047337, ...
    0.072947413,0.336198006,0.066475609,0.126214652, ...
    0.317079852,0.27991453,0.283377,0.678663239, ...
    0.641695044,0.475396825,0.01628468,0.453174833, ...
    0.503257329,0.178529063,0.085577841,0.538696538, ...
    0.283377,0.447154472,0.283377,0.12295082, ...
    0.066977286,0.307692308,0.476665252,0.12597229, ...
    0.279153396,0.596039604];

deathS = [0.02,0.02,0.14,0.01,0.02,0.01,0.02,0.04,0 ...
    ,0.01,0.03,0.03,0.02,0,0.01,0.01,0.03,0.01,0.01,0.03, ...
    0.02,0.08,0.06,0.05,0.04, 0,0.03,0.04,0.01,0.01,0.04,0, ...
    0.04,0.15,0.01,0.01,0.03,0.04,0.01,0.02,0.05]./1000; %inc per 1000

avg = 75;

countryprop =[67,48,avg,84,78,78,80,81,avg,81,71,84,avg,avg,79,avg,avg,73,73,73,avg,77,avg,83,73,avg,avg,avg,80,avg,avg,avg,77,80,avg,82,81,77,75,avg,avg]./100;

CountryNames={
    'Angola' 
'Benin' 
'Botswana'
'Burkina Faso'
'Burundi'
'Cameroon'
'CAR'
'Chad'
'Comoros'
'Congo'
'DRC'
'Cote d lvoire'
'Djibouti'
'Eritrea'
'Ethiopia'
'Gabon'
'The Gambia'
'Ghana'
'Guinea'
'Guinea Bissau'
'Kenya'
'Liberia'
'Madagascar'
'Malawi'
'Mali'
'Mauritania'
'Mozambique'
'Namibia'
'Niger'
'Nigeria'
'Rwanda'
'Sao Tome & Principe'
'Senegal'
'Sierra Leone'
'Somalia'
'Sudan North'
'Tanzania'
'Togo'
'Uganda'
'Zambia'
'Zimbabwe'
};

%parameters for DALY calculations
Dm=0.2078;
Lm=5.1;
Rm=1-PropSevere; %prop uncomplicated malaria
Ds=0.443;  
Ls=8.75;
Rs=0.0057;
Dn=0.471;
Ln=10.1;
Rn=0.098;
Da=0.149;
La=11;
Ra=0.322;
Dc=0.471;
Lc=6.5;
Rc=0.002;
Dna=0.483;
Lna=11;
Rna=0.322*0.098;
Dca=0.471+0.149;
Lca=11;
Rca=0.00096;

L=55*365; 
deathN=0.1835./1000; %all are cases per 1000
deathA=0.097./1000;
deathC=0.192./1000;
deathNA=0.1835./1000;
deathCA=0.347./1000;