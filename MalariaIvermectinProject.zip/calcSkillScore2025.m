calcSkill = true; false;
if calcSkill == true
    for i=1:numel(poplist) %
        tempscore = zeros(sampsize,1);
        alpha0 = alphalist(i);
        N = poplist(i);
        prevtest = prevlist(i);
        mlist = ( (1/365).*EIRlist(i).*N.*(c.*beta.*prevtest+365.*d0)./(c.^2.*beta*prevtest) )./N;
        
        for j=1:sampsize
            prop = 0;
            m = mlist(j);
            Delta0 = 1./( (1-0.459*prop).*1./d0(j) + 0.459*prop.*1/newd0(j));
            param = [rp(j),ru(j),rd(j),rt(j),ra(j),ft(j),phi(j), ...
                alpha0 ...
                ,beta(j),Delta0,c(j),N,m,n(j),prop,psi(j)];
            
            [tempscore(j), MSref(j), MSfor(j)] = Validate2019(alphalist(i),i,param);
                        
        end
        
        %store avg skill score across all parameter samples for ith country
        skillscore(i) = mean(tempscore);
        meanMSref(i) = mean(MSref);
        meanMSfor(i) = mean(MSfor);
    end
end


