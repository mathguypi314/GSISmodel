rng(101010)
clear mybase
clear myiver
clear myratio
%%%%%%%%%%%%%%%%%This script estimates the reduction in transmission factor
%%%%%%%%%%%%%%%%%caused by ivermectine

opt = odeset('NonNegative',1:8);

% prevalence of infection = 1 - prop w/ 0 episodes = 1 - (64+23)/(327+263)
% number of incidence = 648 + 647 = 1295 = c*alpha*Mi/M*S*126
%
% it also follows that  365*c*Mi/N = EIR = 61.15
%
% so 1295 = 126/365 * N/M*alpha*EIR*S
%    1295 = 126/365 * N*0.25*61.15*S/M

for w=1:201 
    i=4;
    t = 0:0.5:126;
    
    N = poplist(i);
    prevtest = prevlist(i);
    
    %Estimate ratio of mos pop to human pop at baseline
    mlist = ( (1/365).*EIRlist(i).*N.*(c.*beta.*prevtest+365.*d0)./(c.^2.*beta*prevtest) )./N;
    
    for j=1:sampsize
        
        m = mlist(i); %ratio of mosquitoes to humans (for ith param sample)
        
        for intervention=1:2
            if intervention==1
                propMI = c.*beta.*(prevtest/365)./(c.*beta.*(prevtest/365) +d0);
                
                Mi0 = N.*m*propMI(i); 
                Ms0 = N.*m-Mi0;
                
                Alpha = 0.2*k; %alphalist(i); %k*alpha(j);
                prop = 0; %no one on ivermectine for baseline
                M = m*N;
                S0 = M.*rp.*(c.^2.*Alpha.^2.*Mi0.^2.*phi.*ft+M.*c.*ft.*Mi0.*phi.*(ra+ru).*Alpha+ra.*M.^2.*ru).*rt.*N.*rd./((c.*Mi0.*(((1-ft).*rt+rd.*ft).*rp+rd.*rt.*ft).*phi.*Alpha+rd.*rp.*rt.*M).*(ra.*M+c.*Alpha.*Mi0).*(ru.*M+c.*Alpha.*Mi0));
                A0 = -(phi.*ft-1).*rd.*M.*c.*Alpha.*Mi0.*rp.*rt.*N./((ra.*M+c.*Alpha.*Mi0).*(c.*Mi0.*(((1-ft).*rt+rd.*ft).*rp+rd.*rt.*ft).*phi.*Alpha+rd.*rp.*rt.*M));
                T0 = ft.*phi.*rd.*c.*Alpha.*Mi0.*N.*rp./(c.*Mi0.*phi.*(((rd-rt).*ft+rt).*rp+rd.*rt.*ft).*Alpha+rd.*rp.*rt.*M);
                D0 = -N.*rt.*rp.*Mi0.*Alpha.*c.*(ft-1).*phi./(c.*Mi0.*(((1-ft).*rt+rd.*ft).*rp+rd.*rt.*ft).*phi.*Alpha+rd.*rp.*rt.*M);
                U0 = -rd.*M.^2.*c.*Alpha.*Mi0.*rp.*ra.*rt.*N.*(phi.*ft-1)./((c.*Mi0.*(((1-ft).*rt+rd.*ft).*rp+rd.*rt.*ft).*phi.*Alpha+rd.*rp.*rt.*M).*(ra.*M+c.*Alpha.*Mi0).*(ru.*M+c.*Alpha.*Mi0));
                P0 = ft.*phi.*rd.*c.*Alpha.*Mi0.*rt.*N./(c.*Mi0.*phi.*(((-rp+rd).*ft+rp).*rt+rd.*ft.*rp).*Alpha+rd.*rp.*rt.*M);

                Delta0 = d0(j);
                
            else
                %account for effect of iver on # of inf mos
                prop =1447/(1447+1265); %0.5336;
                muval = 0.005*(w-1) + (w==1)*0.00001;
                Alpha = muval*0.2*k; %mu*k*alpha(j);
                Delta0 = 1./( (1-0.459*prop).*1./d0(j) + 0.459*prop.*1/newd0(j));
                %use doi.org/10.1038/s41598-021-04106-w for info oncmosquito feeding preference
            end
            
            param = [rp(j),ru(j),rd(j),rt(j),ra(j),ft(j),phi(j), ...
                Alpha ...
                ,beta(j),Delta0,c(j),N,m,n(j),prop,psi(j)];
            
            state = [S0(j),A0(j),U0(j),T0(j),D0(j),P0(j),Ms0,Mi0];
            
            [t,X]=ode45(@(t,ic)IVMMalODEs_ext(t,ic,param),t,state,opt);
            
            S=X(:,1);
            A=X(:,2);
            U=X(:,3);
            Tau=X(:,4);
            D=X(:,5);
            P=X(:,6);
            
            %include the following for extended model:
            Ms=X(:,7);
            Mi=X(:,8);
            
            I = A+U+D+Tau;
            
            %FOI (at eqb)
            Lambda = c(j)*Alpha*Mi/M;
            
            if intervention==1
                mybase(j) = trapz(t,Lambda.*S);
                baseS=S;
            else
                myiver(j) = trapz(t,Lambda.*S);
                iverS = S;
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        end
    end
    myratio(w) = mean(myiver./mybase);
end
%%
%max(find(myratio<2/(2.49*(1-prop)+2*prop)))
%(max(find(myratio<2/(2.49*(1-prop)+2*prop)))-1)*0.005
%mean(mybase)/N

%%
% width=6.5;
% height=2;
% alw= 0.75*4;
% fsz= 12; 12; (30*3-30)/(1+1/6); 30;
% lw=2; 4*3; 6*3;
% msz=10*3;
figure(73)
clf;

set(gcf,'InvertHardcopy','on');
set(gcf,'PaperUnits', 'inches');
papersize = get(gcf, 'PaperSize');
left = (papersize(1)- width)/2;
bottom = (papersize(2)- height)/2;
myfiguresize = [left, bottom, width, height*1.5];
set(gcf,'PaperPosition', myfiguresize);

plot(0:0.005:1,myratio,'b',[0, 1],[2/(2.49*(1-prop)+2*prop) 2/(2.49*(1-prop)+2*prop)],'--k','linewidth',lw)

set(gca,'fontsize',fsz,'linewidth',lw)
box off;
xlabel("\mu")
ylabel("Ratio")
%print('muplot','-dpng','-r300');