calcAlphaBeta = true; false;

if calcAlphaBeta == true
    %beta0 = 0.43;
    myopt=optimset('MaxFunEvals',14000,'TolFun',1e-16,'TolX',1e-16,'MaxIter',2000,'algorithm','sqp');
    
    %use as starting point for each countries' estimate
    OLDalphalist = [0.0415304206521249,0.0364946449037923,0.0245408074836818,0.0349636274712531,0.0323552492019611,0.0346454499155781,0.0339912757371085,0.0399845745868574,0.0283706476376609,0.0358118121635440,0.0351271713941803,0.0326132633640799,0.0387529228723360,0.0212237319019009,0.0292073188484581,0.0351391740956167,0.0398974650122685,0.0320042466592983,0.0348286062596606,0.0373579550159167,0.0314762709788148,0.0337886032687835,0.0339880676809645,0.0351176052313748,0.0438130756914694,0.0300396378816147,0.0356129063663385,0.0291461563441358,0.0362284439483968,0.0353507543436387,0.0429048775610552,0.0318281463994911,0.0380849927519818,0.0342898261373766,0.0352595208497058,0.0352677713837876,0.0362483175840845,0.0318179981407863,0.0317115177050707,0.0367543776148036,0.0397450468183540];

    alphalist = zeros(1,41);
    alphalist2 = zeros(1,41);
    alphaest = zeros(1,sampsize);
    
    
    for i=1:numel(poplist) %
        alpha0 = OLDalphalist(i);
        N = poplist(i);
        prevtest = prevlist(i);
        mlist = ( (1/365).*EIRlist(i).*N.*(c.*beta.*prevtest+365.*d0)./(c.^2.*beta*prevtest) )./N;
        
        for j=1:sampsize
            prop = 0;
            m = mlist(j);
            Delta0 = 1./( (1-0.459*prop).*1./d0(j) + 0.459*prop.*1/newd0(j));
            param = [rp(j),ru(j),rd(j),rt(j),ra(j),ft(j),phi(j), ...
                alpha0 ...
                ,beta(j),Delta0,c(j),N,m,n(j),prop,psi(j)];
            
            
            tempfun = @(A)findAlphas(A,i,param);
            
            [x,fval] = fmincon(tempfun,[alpha0],[],[],[],[],[alpha0/20],[alpha0*20],[],myopt);
            
            alphaest(j) = x(1);
        end
        
        %store median and mean alpha's for each country
        alphalist(i) = median(alphaest);
        alphalist2(i) = mean(alphaest);
    end
end


