opt = odeset('NonNegative',1:8);

for i=1:numel(poplist)
    
    N = poplist(i);
    prevtest = prevlist(i);
    
    %Estimate ratio of mos pop to human pop at baseline
    mlist = ( (1/365).*EIRlist(i).*N.*(c.*beta.*prevtest+365.*d0)./(c.^2.*beta*prevtest) )./N;
    
    for j=1:sampsize
        
        m = mlist(j); %ratio of mosquitoes to humans (for ith param sample)

        Delta0 = 1./( (1-0.459*prop).*1./d0(j) + 0.459*prop.*1/newd0(j));

        propMI = c.*beta.*(prevtest/365)./(c.*beta.*(prevtest/365) +Delta0);
        
        Mi0 = N.*m*propMI(j);
        Ms0 = N.*m-Mi0;
        
        Alpha = alphalist(i); % k.*alpha(j); %make sure IC are same for baseline and intervention
        M = m*N;
        
        prop=proplist(ii);
        
        S0 = M.*rp.*(c.^2.*Alpha.^2.*Mi0.^2.*phi.*ft+M.*c.*ft.*Mi0.*phi.*(ra+ru).*Alpha+ra.*M.^2.*ru).*rt.*N.*rd./((c.*Mi0.*(((1-ft).*rt+rd.*ft).*rp+rd.*rt.*ft).*phi.*Alpha+rd.*rp.*rt.*M).*(ra.*M+c.*Alpha.*Mi0).*(ru.*M+c.*Alpha.*Mi0));
        A0 = -(phi.*ft-1).*rd.*M.*c.*Alpha.*Mi0.*rp.*rt.*N./((ra.*M+c.*Alpha.*Mi0).*(c.*Mi0.*(((1-ft).*rt+rd.*ft).*rp+rd.*rt.*ft).*phi.*Alpha+rd.*rp.*rt.*M));
        T0 = ft.*phi.*rd.*c.*Alpha.*Mi0.*N.*rp./(c.*Mi0.*phi.*(((rd-rt).*ft+rt).*rp+rd.*rt.*ft).*Alpha+rd.*rp.*rt.*M);
        D0 = -N.*rt.*rp.*Mi0.*Alpha.*c.*(ft-1).*phi./(c.*Mi0.*(((1-ft).*rt+rd.*ft).*rp+rd.*rt.*ft).*phi.*Alpha+rd.*rp.*rt.*M);
        U0 = -rd.*M.^2.*c.*Alpha.*Mi0.*rp.*ra.*rt.*N.*(phi.*ft-1)./((c.*Mi0.*(((1-ft).*rt+rd.*ft).*rp+rd.*rt.*ft).*phi.*Alpha+rd.*rp.*rt.*M).*(ra.*M+c.*Alpha.*Mi0).*(ru.*M+c.*Alpha.*Mi0));
        P0 = ft.*phi.*rd.*c.*Alpha.*Mi0.*rt.*N./(c.*Mi0.*phi.*(((-rp+rd).*ft+rp).*rt+rd.*ft.*rp).*Alpha+rd.*rp.*rt.*M);

        Alpha = mu(j)*alphalist(i); %mu(j)*k*alpha(j);
                
        param = [rp(j),ru(j),rd(j),rt(j),ra(j),ft(j),phi(j), ...
            Alpha ...
            ,beta(j),Delta0,c(j),N,m,n(j),prop,psi(j)];
        
        state = [S0(j),A0(j),U0(j),T0(j),D0(j),P0(j),Ms0,Mi0];
        
        [t,X]=ode45(@(t,ic)IVMMalODEs_ext(t,ic,param),t,state,opt);
        
        S=X(:,1);
        A=X(:,2);
        U=X(:,3);
        Tau=X(:,4);
        D=X(:,5);
        P=X(:,6);
        
        %include the following for extended model:
        Ms=X(:,7);
        Mi=X(:,8);
        
        %all human infectious classes
        I = A+U+D+Tau;
        
        %FOI 
        Lambda = c(j).*Alpha.*Mi/M;
        
        %stores the 'new' incidence over time.
        IVMinctraj(:,i) = Lambda.*S; 
                
        %new people in 'clinical disease'
        TotIVMclinicInc(i,j) = trapz(t,phi(j).*(1-ft(j)).*Lambda.*(S+A+U));
        TotIVMInc(i,j) = trapz(t,IVMinctraj(:,i));
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        IVMdcalc(i,j) = trapz(t,exp(-r*t).*IVMinctraj(:,i));
        
        if mod(i,10)==1
            sprintf("Intervention %i of 3, Country <= %i completed",ii,i)
        end
    end
end