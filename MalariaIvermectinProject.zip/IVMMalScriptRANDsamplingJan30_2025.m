clear;
clc;

%variables for creating plots
width=34;
height=22;
alw= 0.75*4;
fsz= (30*3-30)/(1+1/6);  
lw=4*3; 
msz=10*3;

%sample size
sampsize = 100000;
%%
run('IVMMalDataAndParamRANDsampling2025') %randomly sample parameters from distributions

%%%%%%%%%%%%%%%%%%%Initialize arrays for storage%%%%%%%%%%%%%%%%%%%%%
mlist = zeros(size(poplist)); %ratio of mosquitoes to human
errlist = zeros(size(poplist)); %store error from fitting alpha's
dcalc = zeros(numel(poplist),sampsize); %store quantities needed for DALY calc
TotclinicInc = zeros(numel(poplist),sampsize); %Total clinical incidence (i.e. reported to health care setting)
TotInc = zeros(numel(poplist),sampsize); %Total incidence
TotInc2019 = zeros(numel(poplist),sampsize); 
TotIVMclinicInc = zeros(numel(poplist),sampsize); %Total clinical incidence under ivermectin intervention
TotIVMInc = zeros(numel(poplist),sampsize); %Total inc under ivermectin intervnetion
skillscore = zeros(41,1); %store the skill score for each scenario
meanMSref = zeros(41,1); %store the mean square error from the reference data set (2018 malaria inc)
meanMSfor = zeros(41,1); %store the mean square error from the forecast data set (2019 malaria inc)
%%
% Run findAlphas to est trans prob for each country
% this is the script calcAB 
%run('calcAB2025'); %note this takes awhile

% alpha list is obtained from running calcAB (alpha was fit for 10000
% random param samples for each country. Then, we calc avg of alpha for
% each country:

alphalist = [0.0478328229444498,0.0469576367544213,0.0296019453713804,0.0444371534726857,0.0406606521633609,0.0427098493855973,0.0423791286913001,0.0481716695523423,0.0337738651080761,0.0442177886907731,0.0309479957268284,0.0780220487928929,0.0448126828368359,0.0190558397382686,0.0347340314755026,0.0432360459437646,0.0464417631364925,0.0390302103618479,0.0441294070911127,0.0435563675522455,0.0374215598588032,0.0433321156437235,0.0401894150542741,0.0426978568969545,0.0557813455325075,0.0358554334440568,0.0448099417172533,0.0346130535012460,0.0456768898980636,0.0435769042340232,0.0545467552175927,0.0373642582469280,0.0443508026849808,0.0437830295186827,0.0414841827108016,0.0413871203788694,0.0429598185560371,0.0393304201062405,0.0396813712776861,0.0443909269584107,0.0458963397535377];
%%
%calc the forecast skill score of model
run('calcSkillScore2025'); 

%%
%below is used to estimate reduction factor in trans prob using
%data from study site
run('calibrateIvermectinEffectsSAMP2025')
%
%%
%sorting EIR from lowest to highest
[Q,ind] = sort(EIRlist);

%time interval for simulation
t=0:73:(365*5);

%array to store the trajectory of incidence (at each time step)
inctraj = zeros(numel(t),numel(poplist));

%compute baseline scenario
run('baselineSAMP2025');
%%
%scenarios for prop of pop receiving ivermectin
proplist = [0.125 0.25 0.5];

%%arrays to store costs, inc saved, etc.
avgCostMal = zeros(numel(proplist),41); %Cost of malaria incidences
avgCostIver = zeros(numel(proplist),41); %avg cost of ivermectin treatment
dalysavedlist = zeros(41,numel(proplist)); %list of dalys saved 
incsavedlist= zeros(41,numel(proplist)); %list of inc saved
ICER = zeros(sampsize,41); %Incremental cost effectiveness ratio

%%
%%%%%%%%%%%%%%%%parameters for estimating cost of a malaria incidence 
%%see doi.org/10.1186/1475-2875-10-337
upsilon= 9.31*ones(1,sampsize); %cost of uncomplicated malaria incidence
sigma = 89.93*ones(1,sampsize); %cost of severe malaria incidence

%ivermectin treatment costs (3 tablets) doi: 10.1371/journal.pntd.0004056
%1.5054 (for 3 tablets) + 0.0018*3 (freight costs/insurance)
ivermectinCosts = repmat( (1.5054+0.0018*3)*12,1,sampsize);

%%
for ii=1:numel(proplist)
    prop =proplist(ii);
    
    %simulate model under ivermectin scenario
    run('IVMinterventionSAMP2025');
    
    %%%Compute #'s needed for DALY and ICER calculations
    run('setupForDALYsSAMP2025')
    
    %%%quantity used in DALY calc
    drate = Rs*(...
        (1-Rn-Ra-Rc-Rna-Rca)*deathS ...
        +Rn.*deathN ...
        +Ra.*deathA ...
        +Rc.*deathC ...
        +Rna.*deathNA ...
        +Rca.*deathCA);
    
    %Costs attributed to incidence of malaria (for each random param sample)
    c0=((upsilon'.*(1-PropSevere)+sigma'.*PropSevere)).*TotclinicInc';
    
    %Avg costs of incidence of malaria across all parameter samples
    avgCostMal(ii,:) =  mean( ( (upsilon'.*(1-PropSevere)+sigma'.*PropSevere).*TotIVMclinicInc'),1); %use only clinical cases

    %Avg cost of ivermectin
    avgCostIver(ii,:) = mean( repmat(ivermectinCosts',1,41).*prop.*poplist,1)*t(end)/365; 
    
    %intervention costs for each sample
    c14=((upsilon'.*(1-PropSevere)+sigma'.*PropSevere)).*TotIVMclinicInc' ...
        + (repmat(ivermectinCosts',1,41)).*prop.*poplist*t(end)/365;

    %storing health calc from each scenario
    if ii==1 %scenario A ivermectin given to 12.5% pop
        c14a=c14;
        IVMDALYsA=IVMDALYS;
        ICERa = (c0-c14)./(BaseLineDALYS-IVMDALYS);
        INCa = (TotIVMInc-TotInc)'./poplist/5;
        
    elseif ii==2 %scenario B ivermectin given to 25% pop
        c14b=c14;
        IVMDALYsB=IVMDALYS;
        ICERb = (c0-c14)./(BaseLineDALYS-IVMDALYS);
        INCb = (TotIVMInc-TotInc)'./poplist/5;
        
    else %scenario C ivermectin given to 50% pop
        c14c=c14;
        IVMDALYsC=IVMDALYS;
        ICERc = (c0-c14)./(BaseLineDALYS-IVMDALYS);
        INCc = (TotIVMInc-TotInc)'./poplist/5;
    end
    %%%
   
    %compute avg daly saved, inc saved per year per 1000 people
    dalysavedlist(:,ii) = mean(((BaseLineDALYS-IVMDALYS)))'./poplist'/5*1000;
    incsavedlist(:,ii) = mean(((TotInc-TotIVMInc)),2)./poplist'/5*1000;
end
%%
%displaying quantile data for the ICER
[quantile(quantile(ICERa,0.5),0.25), ...
    quantile(quantile(ICERa,0.5),0.5), ...
    quantile(quantile(ICERa,0.5),0.75)]./1000

[quantile(quantile(ICERb,0.5),0.25), ...
    quantile(quantile(ICERb,0.5),0.5), ...
    quantile(quantile(ICERb,0.5),0.75)]./1000

[quantile(quantile(ICERc,0.5),0.25), ...
    quantile(quantile(ICERc,0.5),0.5), ...
    quantile(quantile(ICERc,0.5),0.75)]./1000
%%
%displaying quantile data for inc averted
-1000*[quantile(quantile(INCa,0.5),0.25), ...
    quantile(quantile(INCa,0.5),0.5), ...
    quantile(quantile(INCa,0.5),0.75)]

-1000*[quantile(quantile(INCb,0.5),0.25), ...
    quantile(quantile(INCb,0.5),0.5), ...
    quantile(quantile(INCb,0.5),0.75)]

-1000*[quantile(quantile(INCc,0.5),0.25), ...
    quantile(quantile(INCc,0.5),0.5), ...
    quantile(quantile(INCc,0.5),0.75)]
%%
%displaying quantile data for DALYs averted
1000*[quantile(quantile((BaseLineDALYS-IVMDALYsA)./poplist,0.5),0.25), ...
    quantile(quantile((BaseLineDALYS-IVMDALYsA)./poplist,0.5),0.5), ...
    quantile(quantile((BaseLineDALYS-IVMDALYsA)./poplist,0.5),0.75)]

1000*[quantile(quantile((BaseLineDALYS-IVMDALYsB)./poplist,0.5),0.25), ...
    quantile(quantile((BaseLineDALYS-IVMDALYsB)./poplist,0.5),0.5), ...
    quantile(quantile((BaseLineDALYS-IVMDALYsB)./poplist,0.5),0.75)]

1000*[quantile(quantile((BaseLineDALYS-IVMDALYsC)./poplist,0.5),0.25), ...
    quantile(quantile((BaseLineDALYS-IVMDALYsC)./poplist,0.5),0.5), ...
    quantile(quantile((BaseLineDALYS-IVMDALYsC)./poplist,0.5),0.75)]

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Below is the code for plotting/saving figures %
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
[xx,yy]=sort(GDPlist);

figure(33)
set(gcf,'InvertHardcopy','on');
set(gcf,'PaperUnits', 'inches');
papersize = get(gcf, 'PaperSize');
left = (papersize(1)- width)/2;
bottom = (papersize(2)- height)/2;
myfiguresize = [left, bottom, width/2/1.1846, height*1.5];
set(gcf,'PaperPosition', myfiguresize);

temp = zeros(size(dalysavedlist)); %this is to correctly stack bar plot
temp(:,1) = dalysavedlist(:,1);
temp(:,2) = (dalysavedlist(:,2)-dalysavedlist(:,1));
temp(:,3) = (dalysavedlist(:,3)-dalysavedlist(:,2));
h=barh(temp(yy,:),'stacked');
set(gca,'xtick',[0,0.5,1,1.5,2]);
set(gca,'xticklabels',{'0','','1','','2'});
xlim([0, 2]);
set(gca,'ytick',[1:41])
set(gca,'yticklabels',CountryNames(yy), 'FontSize', fsz, 'LineWidth', lw);
xlabel({'Annual DALYs saved per';'1000 people'});
box off;

%%print('DALYsSaved','-dpng','-r300');
%%
[xx,yy]=sort(GDPlist);

figure(34)
set(gcf,'InvertHardcopy','on');
set(gcf,'PaperUnits', 'inches');
papersize = get(gcf, 'PaperSize');
left = (papersize(1)- width)/2;
bottom = (papersize(2)- height)/2;
myfiguresize = [left, bottom, width/2/1.1846, height*1.5];
set(gcf,'PaperPosition', myfiguresize);

%use temp so you can stack to appropriate height
temp = zeros(size(incsavedlist));
temp(:,1) = incsavedlist(:,1);
temp(:,2) = (incsavedlist(:,2)-incsavedlist(:,1));
temp(:,3) = (incsavedlist(:,3)-incsavedlist(:,2));

h=barh(temp(yy,:),'stacked');
xlim([0,350])
set(gca,'xtick',[0,87.5,175,262.5,350]);
set(gca,'xticklabels',{'0','','175','','350'});
set(gca,'ytick',[1:41])
set(gca,'yticklabels',CountryNames(yy), 'FontSize', fsz, 'LineWidth', lw);

xlabel({'Annual incidence averted','per 1000 people'});
box off;
%%print('INCsSaved','-dpng','-r300');
%%
figure(64)
set(gcf,'InvertHardcopy','on');
set(gcf,'PaperUnits', 'inches');
papersize = get(gcf, 'PaperSize');
left = (papersize(1)- width)/2;
bottom = (papersize(2)- height)/2;
myfiguresize = [left, bottom, width/1.1846, height*1.5/2];
set(gcf,'PaperPosition', myfiguresize);

plot(quantile((BaseLineDALYS-IVMDALYsC)./poplist,0.5),-quantile((c0-c14c)./poplist,0.5),'*',...
    [0 0.015],250.*[0 0.015],'-.k', ...
    'linewidth',lw,'MarkerSize',1.5*lw)
set(gca,'FontSize', fsz, 'LineWidth', lw);

xlim([0 0.011])
ax = gca;

ylabel('Cost per person');
set(ax,'XAxisLocation','origin','YAxisLocation','origin');
xlh=xlabel('DALYs averted per person');
xlh.Position(2) = -25 ;-xlh.Position(2)-6;
xlh.Position(1) = xlh.Position(1)/1.25;
box off;
%%print('Cost-benefit-plot','-dpng','-r300');

%%
figure(23)
set(gcf,'InvertHardcopy','on');
set(gcf,'PaperUnits', 'inches');
papersize = get(gcf, 'PaperSize');
left = (papersize(1)- width)/2;
bottom = (papersize(2)- height)/2;
myfiguresize = [left, bottom, width/2/1.1846, height*1.5];
set(gcf,'PaperPosition', myfiguresize);

%use temp so you can stack to appropriate height
temp = skillscore;
h=barh(temp(yy),'stacked');
set(gca,'ytick',[1:41])
set(gca,'yticklabels',CountryNames(yy), 'FontSize', fsz, 'LineWidth', lw);
xlabel({'Skill Score'});
box off;
set(gca,'XScale','log')
set(gca, 'YAxisLocation', 'right');
%print('Skillscore','-dpng','-r300');

figure(24)
set(gcf,'InvertHardcopy','on');
set(gcf,'PaperUnits', 'inches');
papersize = get(gcf, 'PaperSize');
left = (papersize(1)- width)/2;
bottom = (papersize(2)- height)/2;
myfiguresize = [left, bottom, width/2/1.1846, height*1.5];
set(gcf,'PaperPosition', myfiguresize);
temp = meanMSref;
h=barh(temp(yy,:),'stacked');
set(gca,'ytick',[1:41])
set(gca,'yticklabels',CountryNames(yy), 'FontSize', fsz, 'LineWidth', lw);
xlabel({'MSref'});
box off;
set(gca,'XScale','log')
%print('MSref','-dpng','-r300');

figure(25)
set(gcf,'InvertHardcopy','on');
set(gcf,'PaperUnits', 'inches');
papersize = get(gcf, 'PaperSize');
left = (papersize(1)- width)/2;
bottom = (papersize(2)- height)/2;
myfiguresize = [left, bottom, width/2/1.1846, height*1.5];
set(gcf,'PaperPosition', myfiguresize);
temp = meanMSfor;
h=barh(temp(yy,:),'stacked');
set(gca,'ytick',[1:41])
set(gca,'yticklabels',CountryNames(yy), 'FontSize', fsz, 'LineWidth', lw);
xlabel({'MSfor'});
box off;
set(gca,'XScale','log')
%print('MSfor','-dpng','-r300');
