function dX=IVMMalODEs_ext(t,X,parm)
rp = parm(1);
ru = parm(2);
rd = parm(3);
rt = parm(4);
ra = parm(5);
ft = parm(6);
phi= parm(7);
alpha = parm(8);
beta = parm(9);
d0 = parm(10);
c = parm(11);
N = parm(12); %poplist
M = parm(13); %this is ratio of humans to mos
n = parm(14);
prop = parm(15);
psi = parm(16); 0.446; %prop of mos that die from feeding on person taking ivermectin

S = X(1);
A = X(2);
U = X(3);
Tau = X(4);
D = X(5);
P = X(6);

Ms = X(7);
Mi = X(8);

I = A+U+D+Tau;

%lambda = c^2*M*alpha*beta*I/(c*beta*I+d0*N);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%lambda= c*alpha*Mi/N; %alpha implicitly reflects effect of reduced transmission
lambda= c*alpha*Mi/(Mi+Ms); %alpha implicitly reflects effect of reduced transmission

lambdaM = c*beta*I/N; 


%mos w/ iver survive 2.3 days vs 5.5 days for ctrl grp [data values come
%from https://academic.oup.com/jid/article/202/1/113/888773]

newd0 = d0;
%newd0 = 1./((1-psi*prop)*1/d0 + psi*prop*(2.3/5.5*1/d0));

%ratio of bites on human vs animal 3.4:1  cite doi:10.1017/S0007485300055279

%1/newd0 = (1-psi*prop)*1/d0 + psi*prop*(2.3/5.5*1/d0)

%(1-psi*(prop)) factor by which mos pop is reduced by ivermectin
%prop = 0;

%dMs = d0*M*N -lambdaM*Ms - d0*Ms + psi*(prop)*c*Mi; %+ psi*prop*c*beta*Mi; %added psi*phi*lambdaM*Mi to account for effect of mosquito death / conservatino of population%psi*phi*lambdaM*M-psi*phi*lambdaM*Ms
%dMi = lambdaM*Ms - d0*Mi - psi*(prop)*c*Mi; %psi*(prop)*c*Mi is prop of bites by inf mos on people treated w/ ivermectin

dMs = d0*M*N -lambdaM*Ms - d0*Ms; %+ psi*prop*c*beta*Mi; %added psi*phi*lambdaM*Mi to account for effect of mosquito death / conservatino of population%psi*phi*lambdaM*M-psi*phi*lambdaM*Ms
dMi = lambdaM*Ms - d0*Mi; %psi*(prop)*c*Mi is prop of bites by inf mos on people treated w/ ivermectin


dS = P*rp + U*ru - lambda * S; %Susceptilbe
dA =lambda*(1-phi)*(S+U) + D*rd - A*ra  -lambda*phi*A; %Asymptomatic
dT =lambda*phi*ft*(S+A+U)-Tau*rt;
dD =lambda*phi*(1-ft)*(S+A+U)-D*rd; %Clinical infection
dU = A*ra - U*ru  -lambda*U; %Sub-clinical infection
dP = Tau*rt-P*rp; %Receive AL

%return output
dX = [dS dA dU dT dD dP dMs dMi]';