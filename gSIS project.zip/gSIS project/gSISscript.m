%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Code for 
%
%         1) fitting/simulating the gSIS model
%         2) fitting/simulating the SIS model
%         3) Calculating AIC for gSIS and SIS models
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% General setup

clear;
clc;

%parameters for saving plots
width=34;
height=22;
alw= 2;
fsz= 12; 
lw= 2;

%Days for infectious period distribution
x =0:61; 

%Frequency of infections
durinf=[0,4,23,31,60,26,20,8,35,1,0,1,0,2,0,0,0, ...
    0,0,0,0,14,0,0,0,0,0,0,0,0,5,0,0,0,0,0,...
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,...
    0,0,0,0,6,1];

%normalize distribution
durinf=durinf./sum(durinf);

%survival function (from data)
sdata = 1-cumsum(durinf); 

%Estimate mean duration of infection
sampMU=trapz(x,sdata)/7; %divide by 7 to convert to weeks

%Incidence data collected from CDC (weekly)
incdata = [2111,4111,4109,3864,3342,3513,3130,3212,2824,3036,3381,3114,1614,2316,2044,2990,2562,...
    2686,2907,2492,2952,2818,2898,2863,2914,906,3232,3428,2645,3403,3656,3710,3746,4478,...
    4668,4334,4151,4767,5259,4125,5312,4604,4944,5134,3448,4781,5232,3642,4727,5006,2973,...
    2715,3121];

%Time (for incidence data)
Week = 0:(numel(incdata)-1); 

%% Setup for parameter fit of gSIS
%lower bounds of parameters 
lb = [0.01 0.5 -0.999 0 0];

%upper bounds of parameters
ub = [0.2 1.5 0.999 1/2/pi 2000000];

%extra options to pass to fmincon
myopt=optimset('Algorithm','sqp','Display','iter','MaxFunEvals',1500);

%inital values of freeparam =  [i0,  beta, alpha, w, N]
freeparam = [0.0166095215683371,0.966,-0.256632380475453,0.157395967142766,219992.471892095];
[0.0165174141794505,0.965994691407266,-0.256816519968748,0.157375119020859,218683.953541512];

%% 
%smooth data
f = fit(Week',incdata','smoothingspline','SmoothingParam',0.01); %smooth data

%plot to make sure smoothed function is decent
%plot(Week,f(Week),Week,incdata);

%%
%estimate parameters that minimize least sqr error between incidence data and model
estparam=fmincon(@(p)fitgSIS(p), freeparam,[],[],[],[],lb,ub,[],myopt);

%% Assign parameters 
i0 = estparam(1);
beta=estparam(2);
alpha=estparam(3);
w=estparam(4);
N = estparam(5);

%based on literature (mult by 7 b/c we're dealling with weekly time scale)
b = 0.024/365*7; 

%based on literature (use this to estimate rho given other parameters)
mymu = @(mu,rho,w,alpha)(rho*(w^2+rho^2)/(w^2+(1-alpha)*rho^2)*(rho^(-2)-alpha*(rho^2-w^2)/(rho^2+w^2)^2)-mu);

%solve for rho, with starting point close to mu = 1.06
rho = fzero(@(rho)mymu(sampMU,rho,w,alpha),1/1.06); %rho is in WEEKs, not days.

%%
%simulation to match incidence data
[~,y] = ode45(@(t,x)Iodes(t,x,beta,rho,alpha,w,b),Week,i0);

%simulation that predicts future trend (smaller time step)
[~,y2] = ode45(@(t,x)Iodes(t,x,beta,rho,alpha,w,b),0:300,i0);


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SIS model
%
% repeat, but impose parameters alpha = w = 0 so model corresponds to
% classical SIS model.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Setup for parameter fit of SIS
%lower bounds of parameters 
lb = [0.01 0 0 0 0]; %set bounds for alpha and w to 0

%upper bounds of parameters
ub = [0.2 2 0 0 2000000]; %set bounds for alpha and w to 0

%extra options to pass to fmincon
myopt=optimset('Algorithm','sqp','Display','iter','MaxFunEvals',1500);

%inital values of freeparam =  [i0,  beta, alpha, w, N]
myparam = [0.0165174141794505,0.965994691407266,0,0,218683.953541512];  %set initial values%of alpha and w to 0

%%
%estimate parameters that minimize least sqr error between incidence data and model
EXPparam=fmincon(@(p)fitgSIS(p), ...
    myparam,[],[],[],[],lb,ub,[],myopt);
%%
%Assign parameters (case when duration of infection is exponentially distributed) 
i0exp = EXPparam(1);
betaexp=EXPparam(2);
alphaexp=EXPparam(3);
wexp=0; EXPparam(4);
Nexp = EXPparam(5);
b = 0.024/365*7; %mult by 7 b/c we're dealling with weekly time scale

%solve for rho, with starting point close to mu = 1.06
rhoexp = fzero(@(rho)mymu(sampMU,rho,wexp,alphaexp),1/1.06); %who is in WEEKs, not days.

%%
%estimate baseline

%simulation to match incidence data
[~,baseline0] = ode45(@(t,x)Iodes(t,x,betaexp,rhoexp,0,0,b),Week,i0exp);

%simulation that predicts future trend
[~,baseline] = ode45(@(t,x)Iodes(t,x,betaexp,rhoexp,0,0,b),0:300,i0exp);

%%
% plot traj of I(t) for data, gSIS model, SIS model

figure(01)
clf;
plot(Week,incdata,':k',0:300,N*beta*(1-y2(:,1)).*y2(:,1),'--b',0:300,Nexp*betaexp*baseline(:,1).*(1-baseline(:,1)),'r','linewidth',lw)
xlim([0 300]);
ylabel('New infections')
xlabel('Time (weeks)');
box off
set(gca,'linewidth',lw)
set(gca,'TickDir','out');
hh=legend('Data','Periodic','Exp');
set(hh,'box','off','location','northwest');
%%
% plot of (parametric) survival function for duration of infection distribution
 x2=0:300; %2*pi/w.*[-1/40:0.01:0.594]

%%%%%Taking m(t), m'(t), and eta(t) directly from manuscript
 MRL =@(t)((-rho^4*alpha+rho^2*alpha*w^2).*cos(w*t)+2*rho^3*alpha*w*sin(w*t)+(w^2+rho^2)^2)./((w^2+rho^2)*(-2*rho^2*alpha*cos((1/2)*w*t).^2+2*alpha*w*rho*sin((1/2)*w*t).*cos((1/2)*w*t)+(1+alpha)*rho^2+w^2)*rho);
 dM = @(t,m)(-rho*(w^2+rho^2).*(alpha*cos(w*t)-1).*m./(w^2+rho^2-alpha*rho^2*cos(w*t)+alpha*w*rho*sin(w*t))-1);
 Eta = @(t)(rho*(w^2+rho^2).*(1-alpha*cos(w*t))./(w^2+rho^2-alpha*rho^2*cos(w*t)+alpha*w*rho*sin(w*t)));

figure(02)
plot(x2,(dM(x2,MRL(x2))+1)./MRL(x2))
 x3=x2(1):0.1:x2(end);
plot((0:61)./7,sdata,':k',x3,exp(-cumtrapz(x3,Eta(x3))),'--b',x3,exp(-7/rhoexp*x3/7),'r','linewidth',lw)
xlim([0 9])
ylabel('Probability')
xlabel('Time (weeks)');
box off;
set(gca, 'FontSize', fsz, 'LineWidth', alw);
set(gca,'linewidth',lw)
set(gca,'TickDir','out');
hh=legend('Data','Periodic','Exp');
set(hh,'box','off');

%%
%plot of hazard rates
figure(33)
plot(x2,7.*MRL(x2),'--b',[x2(1) x2(end)],[7/rhoexp 7/rhoexp],'r','linewidth',lw)
ylabel('Duration (days)')
xlabel('Time (weeks)');
ylim([7 8]);
xlim([0 100]);
yticks([7:0.25:8]);
hh=legend('Periodic','Exp');
set(hh,'box','off');
box off
set(gca, 'FontSize', fsz, 'LineWidth', alw);
set(gca,'linewidth',lw)
set(gca,'TickDir','out');
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Estimation of AIC
%
% Note: AIC = N*(log(2*pi)+1)+N*log( SumSQR/N) + 2*(k+1)
%
% where
%
% N = # data pts
% k = # of param
% SumSQR = sum of square error

%number of data points (incidence)
M = numel(incdata);

%number of parameters to estimate in gSIS model
k1=5; 

%number of parameters to estimate in SIS model
k2=3; 

%new incidence predicted by gSIS model
lambda1 = N*beta*y2(1:M,1).*(1-y2(1:M,1));

%new incidence predicted by SIS model
lambda2 = Nexp*beta*baseline(1:M,1).*(1-baseline(1:M,1));

%AIC for gSIS model
AICgsis=M*(log(2*pi)+1)+M*log(sum((lambda1-f(0:(M-1))).^2)./M)+2*(k1+1)

%AIC for SIS model
AICsis=M*(log(2*pi)+1)+M*log(sum((lambda2-f(0:(M-1))).^2)./M)+2*(k2+1)