function di = Iodes(t,X,beta,rho,alpha,w,b)
    %incidence
    i=X(1);
    
    % m(t) - mean residual waiting-time
    m = ((-rho^4*alpha+rho^2*alpha*w^2)*cos(w*t)+2*rho^3*alpha*w*sin(w*t)+(w^2+rho^2)^2)/((w^2+rho^2)*(-2*rho^2*alpha*cos((1/2)*w*t)^2+2*alpha*w*rho*sin((1/2)*w*t)*cos((1/2)*w*t)+(1+alpha)*rho^2+w^2)*rho);
    
    %dm/dt - derivative of mean residual waiting-time
    dm = -rho*(w^2+rho^2)*(alpha*cos(w*t)-1)*m/(w^2+rho^2-alpha*rho^2*cos(w*t)+alpha*w*rho*sin(w*t))-1;
    
    %di/dt - derivative of infected proportion
    di = (beta*(1-i)-b-(2*dm+1)/m)*i;    
end