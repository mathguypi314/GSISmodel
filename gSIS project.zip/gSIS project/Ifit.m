function Err = Ifit(freeparam)

%incidence data
incdata = [2111,4111,4109,3864,3342,3513,3130,3212,2824,3036,3381,3114,1614,2316,2044,2990,2562,...
2686,2907,2492,2952,2818,2898,2863,2914,906,3232,3428,2645,3403,3656,3710,3746,4478,...
4668,4334,4151,4767,5259,4125,5312,4604,4944,5134,3448,4781,5232,3642,4727,5006,2973,...
2715,3121];

%setup
Week = 0:(numel(incdata)-1);
NewWeek = 0:0.1:Week(end); %refined step size
i0 = freeparam(1);
beta = freeparam(2);
%rho = freeparam(3);
alpha = freeparam(4);
w = freeparam(5);
b = 0.024/365*7; %mult by 7 b/c we're dealling with weekly time scale
N = freeparam(7);

%smooth data
f = fit(Week',incdata','smoothingspline','SmoothingParam',0.01);

%avg duration of infection
sampMU = 1.0498; %based of inf period data (in weeks)

%formula for mean 
mymu = @(mu,rho,w,alpha)(rho*(w^2+rho^2)/(w^2+(1-alpha)*rho^2)*(rho^(-2)-alpha*(rho^2-w^2)/(rho^2+w^2)^2)-mu);

%determine rho given other parameters
rho = fzero(@(rho)mymu(sampMU,rho,w,alpha),1/1.06); 

%simulate model
[~,yau] = ode45(@(t,x)Iodes(t,x,beta,rho,alpha,w,b),NewWeek,i0);

%compute new incidence 
newinf=N*beta*(1-yau(:,1)).*yau(:,1);

Err=trapz(NewWeek',(newinf'-f(NewWeek)').^2);
end
